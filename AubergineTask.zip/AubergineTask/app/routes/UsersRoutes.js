
module.exports = (app, express)=>{

    const router = express.Router();
    const UsersController = require('../controllers/UsersController');

    router.post('/register', (req, res, next) => {
        const userObj = (new UsersController()).boot(req, res);
        return userObj.register();
    });


    app.use(config.baseApiUrl, router);
}