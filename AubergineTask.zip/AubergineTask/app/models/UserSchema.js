var mongoose = require('mongoose');
var schema = mongoose.Schema;

var user = new schema({
    firstname : {type:String ,required:true},
    lastname : {type:String ,required:true},
    emailId : {type : String, required: true},
    password : { type: String, required : true},
    country:{type: String}
},{
    timestamps:true
});



var Users = mongoose.model('User', user);

module.exports = {
    Users
}