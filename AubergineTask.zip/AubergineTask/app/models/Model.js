/****************************
 COMMON MODEL
 ****************************/
let _ = require("lodash");

class Model {

    constructor(collection) {
        this.collection = collection;
    }


    // Find single data
    findOne(filter = {}, project = {}) {

        return new Promise((resolve, reject) => {

            this.collection.find(filter, project).exec((err, data) => {

                if (err) { return reject({message: err, status: 0 }); }

                return resolve(data);
            });

        });
    }


    // Store Data
    store(data, options = {}) {

        return new Promise((resolve, reject) => {

            const collectionObject = new this.collection(data)

            collectionObject.save((err, createdObject) => {

                if (err) { return reject({message: err, status: 0 }); }

                return resolve(createdObject);
            });

        });
    }
    
}

module.exports = Model;