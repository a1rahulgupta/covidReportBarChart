const Controller = require("./Controller");
const request = require('request');
const _ = require("lodash");
const bcrypt = require('bcrypt');
const Users = require('../models/UserSchema').Users;
const Model = require("../models/Model");
let nodemailer = require('nodemailer');
const moment = require('moment');
var plotly = require('plotly')("rahulguptaosv1", "Ai1pBIfRFEFJ8Xp7orrW")
var fs = require('fs');

let smtpTransport = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 587,
    secure: false, // use TLS,
    auth: {
        user: ' ', pass: ' '
    },
    debug: true
});

class UsersController extends Controller {
    constructor() {
        super();
    }



    async register() {
        let _this = this;
        var coronaTimelines = [];
        var start_day_date;
        var end_day_date;
        var todayDate = new Date();
        var dateArray = [];
        var coronaDetailsArray = [];
        var coronaDetailsConfirmed = [];
        var coronaDeaths = [];
        var coronaRecovered = [];
        var coronaNewRecovered = [];
        var coronaNewConfirm = [];
        var coronaNewDeaths = [];
        var coronaActive = [];

        try {

            if (!_this.req.body.email || !_this.req.body.firstname || !_this.req.body.lastname || !_this.req.body.password || !_this.req.body.country) {
                return _this.res.send({ status: 0, message: "Please send proper data" });
            }
            const user = await Users.findOne({ "eamilId": _this.req.body.email.toLowerCase() });
            console.log(user)
            if (!_.isEmpty(user) && user.emailId) {
                return _this.res.send({ status: 0, message: "User is exist with above email Id." });
            }
            if (_.isEmpty(user)) {
                let password = bcrypt.hashSync(_this.req.body.password, 10);
                let data = {
                    firstname: _this.req.body.firstname,
                    lastname: _this.req.body.lastname,
                    country: _this.req.body.country,
                    emailId: _this.req.body.email.toLowerCase(),
                    password: password
                }
                const newUser = await new Model(Users).store(data);
                if (_.isEmpty(newUser))
                    return _this.res.send({ status: 0, message: 'User not saved.' })
                let url = `https://corona-api.com/countries/` + data.country + `?include=timeline`
                request(url, { json: true }, (err, res) => {
                    if (err) { return console.log(err); }
                    if (res.body) {
                        
                        coronaTimelines = res.body.data.timeline;
                        start_day_date = moment(todayDate).startOf('day').add(-15, 'days');
                        end_day_date = moment(todayDate).endOf('day');
                        while (start_day_date <= end_day_date) {
                            start_day_date = moment(start_day_date).add(1, 'days');
                            let singleDate = moment(start_day_date).format('YYYY-MM-DD');
                            dateArray.push(singleDate)
                            coronaDetailsArray = coronaTimelines.filter((item) => {
                                if (dateArray.includes(item.date)) {
                                    return item;
                                }
                            });
                        }
                        coronaDetailsArray.filter((item) => {
                            coronaDetailsConfirmed.push(item.confirmed)
                            coronaDeaths.push(item.deaths)
                            coronaRecovered.push(item.recovered)
                            coronaNewRecovered.push(item.new_recovered)
                            coronaNewConfirm.push(item.new_confirmed)
                            coronaNewDeaths.push(item.new_deaths)
                            coronaActive.push(item.active)
                        });
                       
                        var confirmed = {
                            x: dateArray,
                            y: coronaDetailsConfirmed,
                            type: "bar",
                            name:"Confirmed"
                        };
                        var deaths = {
                            x: dateArray,
                            y: coronaDeaths,
                            type: "bar",
                            name:"Deaths"
                        };
                        var recovered = {
                            x: dateArray,
                            y: coronaRecovered,
                            type: "bar",
                            name:"Recovered"
                        };
                        var new_recovered = {
                            x: dateArray,
                            y: coronaNewRecovered,
                            type: "bar",
                            name:"New recovered"
                        };
                        var new_confirmed = {
                            x: dateArray,
                            y: coronaNewConfirm,
                            type: "bar",
                            name:"New Confirmed"
                        };
                        var new_deaths = {
                            x: dateArray,
                            y: coronaNewDeaths,
                            type: "bar",
                            name:"New Deaths"
                        };
                        var active = {
                            x: dateArray,
                            y: coronaActive,
                            type: "bar",
                            name:"Active"
                        };

                        var figure = { 'data': [confirmed, deaths, recovered , new_recovered , new_confirmed , new_deaths , active] };

                        var imgOpts = {
                            format: 'png',
                            width: 1000,
                            height: 500
                        };
                        plotly.getImage(figure, imgOpts, function (error, imageStream) {
                            if (error) return console.log(error);
                            var fileStream = fs.createWriteStream('public/covidreport.png');
                            imageStream.pipe(fileStream);
                            let mailOptions = {
                                from: config.defaultEmailId,
                                to: _this.req.body.email,
                                subject: "Covid Data Representation",
                                html: "Hello<br> Please find below attachment for covid-19 report.",
                                attachments: [
                                    {
                                        path: 'http://localhost:8000/public/covidreport.png'
                                    }
                                ]
                               }
                            smtpTransport.sendMail(mailOptions, (err, result) => {
                                console.log("err, result", err, result)
                                if (err) {
                                    console.log("er =", err);
                                } else {
                                    console.log(result)
                                    _this.res.send({ status: 1, message: 'Congratulation, Corona Reports send syccessfully.' })

                                }
                            })

                        });
                    }
                })
            }

        } catch (error) {
            console.log("error = ", error);
            _this.res.send({ status: 0, message: error });
        }

    }



}
module.exports = UsersController;