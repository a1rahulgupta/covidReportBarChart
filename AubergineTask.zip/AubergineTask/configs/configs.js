/****************************
 Configuration
 ****************************/
module.exports = {
    db: 'mongodb://localhost:27017/userDatabase',
    mongoDBOptions : {
        reconnectTries:  Number.MAX_VALUE,
        reconnectInterval:  1000,
        keepAlive:  1,
        connectTimeoutMS:  30000,
        useMongoClient:  true,
        native_parser: true ,
        poolSize: 5
    },
    sessionSecret: 'indNIC2305',
    securityToken: 'indNIC2305',
    baseApiUrl: '/api',

    serverPort: '8000',
    tokenExpiry: 361440, // Note: in seconds! (1 day)
    defaultEmailId: 'meanstack2017@gmail.com',
    perPage: 20,
    adPerPage:4,
    s3upload:false,
};
