/****************************
 SECURITY TOKEN HANDLING
 ****************************/
let config = require('./configs');
const _ = require('lodash');

class Globals {

    constructor() {

    }
    generateToken(id){
        let _this = this;

        return new Promise(async (resolve, reject) => {

            try {
                // Generate Token
                let token = jwt.sign({
                    id: id,
                    algorithm: "HS256",
                    exp: Math.floor(new Date().getTime() / 1000) + config.tokenExpiry
                }, config.securityToken);

                return resolve(token);

            } catch(err) {
                console.log("Get token", err);
                return reject({message: err, status: 0 });
            }

        });
    }
   

}

module.exports = Globals;